﻿using RoomLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoomLibrary
{
    public class Room
    {
        double roomLength; //длина
        double roomWidth; //ширина
        public double RoomLength
        {
            get { return roomLength; }
            set { roomLength = value; }
        }
        public double RoomWidth
        {
            get { return roomWidth; }
            set { roomWidth = value; }
        }
        /// <summary>
        /// метод вычисляет периметр комнаты 
        /// </summary>
        /// <returns>возвращает периметр</returns>
        public double PoomPerimeter()
        {
            return 2 * (roomLength + roomWidth);
        }
        /// <summary>
        /// вычисляет площадь комнаты 
        /// </summary>
        /// <returns></returns>
        public double RoomArea()
        {
            return roomLength + roomWidth;
        }
        /// <summary>
        /// число кв метров на человека 
        /// </summary>
        /// <param name="np"></param>
        /// <returns>возвращает число кв метров</returns>
        public double PersonArea(int np)
        {
            return RoomArea() / np;
        }
        /// <summary>
        /// информация о комнате
        /// </summary>
        /// <returns></returns>
        public virtual string Info()
        {
            return "комната плащадью" + RoomArea() + "кв.м";
        }

        


       

    }


    public class LivingRoom : Room
    {
        int numWin; //число окон 
        public int NumWin
        { get { return numWin; } set { numWin = value; } }
        public override string Info()
        {
            return "жилая комната площадью" + RoomArea() + "кв,м, с " + numWin + "окнами";

        }
    }
    public class Office : Room
    {
        int numSockets; //число розеток 
        public int NumSockets
        { get { return numSockets; } set { numSockets = value; } }
        /// <summary>
        /// Возврат мах возможное число рабочих мест
        /// </summary>
        /// <returns>Возвращается число мест</returns>
        public int NumWorkplaces()
        {
            int num = Convert.ToInt32(Math.Truncate(RoomArea() / 4.5));
            return Math.Min(numSockets, num);
        }
        public override string Info()
        {
            return "Офис на" + NumWorkplaces() + "рабочих мест";
        }
    }




}


